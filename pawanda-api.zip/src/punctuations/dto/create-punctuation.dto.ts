export class CreatePunctuationDto {}
