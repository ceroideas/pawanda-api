export class CreateCardDto {}
