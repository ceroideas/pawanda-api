export class CreateWalkDto {}
