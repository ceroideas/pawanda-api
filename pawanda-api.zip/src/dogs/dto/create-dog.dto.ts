export class CreateDogDto {}
