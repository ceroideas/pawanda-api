export class CreateRaceDto {}
