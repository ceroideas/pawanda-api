export class CreateProfileDto {
  user: object;

  address: string;

  city: string;

  country: string;

  postal_code: number;

  lat: string;

  lon: string;
}
