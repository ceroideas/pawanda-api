export class CreateBankDatumDto {}
