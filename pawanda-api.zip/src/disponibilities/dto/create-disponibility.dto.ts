export class CreateDisponibilityDto {}
